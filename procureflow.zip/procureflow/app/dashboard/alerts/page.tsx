'use client'

import { useState, useEffect } from 'react'
import { Plus, Bell, Clock, AlertTriangle, Mail, MessageSquare, Edit, Send } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export default function AlertsPage() {
  const [alerts, setAlerts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [companyId, setCompanyId] = useState('')
  const [newAlert, setNewAlert] = useState({
    name: '',
    trigger_type: 'days_before_delivery',
    trigger_value: 7,
    recipient_type: 'buyer',
    notification_channels: ['email'],
  })

  useEffect(() => {
    fetchAlerts()
  }, [])

  const fetchAlerts = async () => {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { data: profile } = await supabase.from('users').select('company_id').eq('id', user.id).single()
    if (!profile) return
    setCompanyId(profile.company_id)

    const { data } = await supabase.from('alert_rules').select('*').eq('company_id', profile.company_id).order('created_at', { ascending: false })
    if (data) setAlerts(data)
    setLoading(false)
  }

  const toggleAlert = async (id: string, isActive: boolean) => {
    const supabase = createClient()
    await supabase.from('alert_rules').update({ is_active: !isActive }).eq('id', id)
    fetchAlerts()
  }

  const handleAddAlert = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    await supabase.from('alert_rules').insert({
      company_id: companyId,
      name: newAlert.name,
      trigger_type: newAlert.trigger_type,
      trigger_value: newAlert.trigger_value,
      recipient_type: newAlert.recipient_type,
      notification_channels: newAlert.notification_channels,
      is_active: true,
      created_by: user?.id,
    })

    setShowModal(false)
    setNewAlert({ name: '', trigger_type: 'days_before_delivery', trigger_value: 7, recipient_type: 'buyer', notification_channels: ['email'] })
    fetchAlerts()
  }

  const toggleChannel = (channel: string) => {
    const channels = newAlert.notification_channels.includes(channel)
      ? newAlert.notification_channels.filter(c => c !== channel)
      : [...newAlert.notification_channels, channel]
    setNewAlert({ ...newAlert, notification_channels: channels })
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div></div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Uyarı Kuralları</h2>
          <p className="text-slate-500 mt-1">Otomatik bildirim kurallarını yönetin</p>
        </div>
        <button onClick={() => setShowModal(true)} className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-sm font-medium text-white hover:shadow-lg transition-all flex items-center gap-2 w-fit">
          <Plus className="w-4 h-4" />
          Yeni Kural
        </button>
      </div>

      <div className="grid gap-4">
        {alerts.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-12 text-center text-slate-500">
            Henüz uyarı kuralı oluşturmadınız
          </div>
        ) : alerts.map((alert) => (
          <div key={alert.id} className={`bg-white rounded-2xl shadow-sm border border-slate-100 p-5 ${!alert.is_active && 'opacity-60'}`}>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  alert.trigger_type === 'days_before_delivery' ? 'bg-blue-100' : 'bg-red-100'
                }`}>
                  {alert.trigger_type === 'days_before_delivery' ? (
                    <Clock className="w-6 h-6 text-blue-600" />
                  ) : (
                    <AlertTriangle className="w-6 h-6 text-red-600" />
                  )}
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">{alert.name}</h4>
                  <p className="text-sm text-slate-500 mt-1">
                    {alert.trigger_type === 'days_before_delivery' 
                      ? `Teslim tarihinden ${alert.trigger_value} gün önce`
                      : `Teslimat ${alert.trigger_value} gün geciktiğinde`}
                  </p>
                  <div className="flex items-center gap-3 mt-3">
                    <span className="text-xs text-slate-500">Alıcı:</span>
                    <span className="px-2 py-1 bg-slate-100 text-slate-600 text-xs font-medium rounded-full">
                      {alert.recipient_type === 'buyer' ? 'Satın Alıcı' : alert.recipient_type === 'supplier' ? 'Tedarikçi' : 'Her İkisi'}
                    </span>
                    <span className="text-xs text-slate-500">Kanallar:</span>
                    <div className="flex items-center gap-1">
                      {alert.notification_channels?.includes('email') && <span className="p-1 bg-slate-100 rounded"><Mail className="w-3.5 h-3.5 text-slate-600" /></span>}
                      {alert.notification_channels?.includes('sms') && <span className="p-1 bg-slate-100 rounded"><MessageSquare className="w-3.5 h-3.5 text-slate-600" /></span>}
                      {alert.notification_channels?.includes('app') && <span className="p-1 bg-slate-100 rounded"><Bell className="w-3.5 h-3.5 text-slate-600" /></span>}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked={alert.is_active} onChange={() => toggleAlert(alert.id, alert.is_active)} className="sr-only peer" />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-100">
              <h3 className="font-semibold text-slate-900">Yeni Uyarı Kuralı</h3>
            </div>
            <form onSubmit={handleAddAlert} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Kural Adı</label>
                <input type="text" value={newAlert.name} onChange={(e) => setNewAlert({...newAlert, name: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl" placeholder="Örn: Teslimat Hatırlatması" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Tetikleyici</label>
                <select value={newAlert.trigger_type} onChange={(e) => setNewAlert({...newAlert, trigger_type: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl">
                  <option value="days_before_delivery">Teslim tarihinden X gün önce</option>
                  <option value="days_after_expected">Teslimat X gün gecikince</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Gün Sayısı</label>
                <input type="number" value={newAlert.trigger_value} onChange={(e) => setNewAlert({...newAlert, trigger_value: Number(e.target.value)})} className="w-full px-4 py-2 border border-slate-200 rounded-xl" min="1" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Alıcı</label>
                <select value={newAlert.recipient_type} onChange={(e) => setNewAlert({...newAlert, recipient_type: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl">
                  <option value="buyer">Satın Alıcı</option>
                  <option value="supplier">Tedarikçi</option>
                  <option value="both">Her İkisi</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Bildirim Kanalları</label>
                <div className="flex gap-3">
                  {['email', 'sms', 'app'].map(channel => (
                    <label key={channel} className="flex items-center gap-2">
                      <input type="checkbox" checked={newAlert.notification_channels.includes(channel)} onChange={() => toggleChannel(channel)} className="rounded border-slate-300 text-cyan-500" />
                      <span className="text-sm text-slate-600">{channel === 'email' ? 'Email' : channel === 'sms' ? 'SMS' : 'Uygulama'}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">İptal</button>
                <button type="submit" className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white font-medium">Kaydet</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
