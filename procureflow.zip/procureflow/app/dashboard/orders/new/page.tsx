'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Plus, Trash2, Loader2 } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { generatePONumber } from '@/lib/utils'

export default function NewOrderPage() {
  const router = useRouter()
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [companyId, setCompanyId] = useState('')
  
  const [formData, setFormData] = useState({
    po_number: generatePONumber(),
    supplier_id: '',
    order_date: new Date().toISOString().split('T')[0],
    expected_delivery_date: '',
    notes: '',
  })

  const [items, setItems] = useState([
    { product_name: '', product_code: '', quantity: 1, unit: 'adet', unit_price: 0 }
  ])

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data: profile } = await supabase.from('users').select('company_id').eq('id', user.id).single()
      if (!profile) return
      setCompanyId(profile.company_id)

      const { data: suppliersData } = await supabase.from('suppliers').select('*').eq('company_id', profile.company_id).eq('status', 'active')
      if (suppliersData) setSuppliers(suppliersData)
    }
    fetchData()
  }, [])

  const addItem = () => {
    setItems([...items, { product_name: '', product_code: '', quantity: 1, unit: 'adet', unit_price: 0 }])
  }

  const removeItem = (index: number) => {
    if (items.length > 1) setItems(items.filter((_, i) => i !== index))
  }

  const updateItem = (index: number, field: string, value: any) => {
    const newItems = [...items]
    newItems[index] = { ...newItems[index], [field]: value }
    setItems(newItems)
  }

  const totalAmount = items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.supplier_id) { alert('Lütfen tedarikçi seçin'); return }
    
    setLoading(true)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    const { data: order, error: orderError } = await supabase.from('purchase_orders').insert({
      company_id: companyId,
      supplier_id: formData.supplier_id,
      po_number: formData.po_number,
      order_date: formData.order_date,
      expected_delivery_date: formData.expected_delivery_date || null,
      total_amount: totalAmount,
      currency: 'TRY',
      notes: formData.notes,
      status: 'pending',
      created_by: user?.id,
    }).select().single()

    if (orderError) { alert('Hata: ' + orderError.message); setLoading(false); return }

    const poItems = items.filter(i => i.product_name).map(item => ({
      po_id: order.id,
      product_name: item.product_name,
      product_code: item.product_code,
      quantity: item.quantity,
      unit: item.unit,
      unit_price: item.unit_price,
      status: 'pending',
    }))

    if (poItems.length > 0) {
      await supabase.from('po_items').insert(poItems)
    }

    router.push('/dashboard/orders')
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/dashboard/orders" className="p-2 hover:bg-slate-100 rounded-lg"><ArrowLeft className="w-5 h-5 text-slate-600" /></Link>
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Yeni Sipariş</h2>
          <p className="text-slate-500">Yeni satın alma siparişi oluşturun</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Sipariş Bilgileri</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Sipariş No</label>
              <input type="text" value={formData.po_number} onChange={(e) => setFormData({...formData, po_number: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/20" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Tedarikçi</label>
              <select value={formData.supplier_id} onChange={(e) => setFormData({...formData, supplier_id: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/20" required>
                <option value="">Seçin...</option>
                {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Sipariş Tarihi</label>
              <input type="date" value={formData.order_date} onChange={(e) => setFormData({...formData, order_date: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/20" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Beklenen Teslim Tarihi</label>
              <input type="date" value={formData.expected_delivery_date} onChange={(e) => setFormData({...formData, expected_delivery_date: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/20" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">Ürünler</h3>
            <button type="button" onClick={addItem} className="px-3 py-1.5 bg-slate-100 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-200 flex items-center gap-1">
              <Plus className="w-4 h-4" /> Ürün Ekle
            </button>
          </div>
          <div className="space-y-4">
            {items.map((item, index) => (
              <div key={index} className="grid grid-cols-12 gap-3 items-end">
                <div className="col-span-4">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Ürün Adı</label>
                  <input type="text" value={item.product_name} onChange={(e) => updateItem(index, 'product_name', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" placeholder="Ürün adı" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Kod</label>
                  <input type="text" value={item.product_code} onChange={(e) => updateItem(index, 'product_code', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" placeholder="Kod" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Miktar</label>
                  <input type="number" value={item.quantity} onChange={(e) => updateItem(index, 'quantity', Number(e.target.value))} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" min="1" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-500 mb-1">Birim Fiyat</label>
                  <input type="number" value={item.unit_price} onChange={(e) => updateItem(index, 'unit_price', Number(e.target.value))} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" min="0" />
                </div>
                <div className="col-span-2 flex items-center gap-2">
                  <span className="text-sm font-medium text-slate-900">₺{(item.quantity * item.unit_price).toLocaleString()}</span>
                  {items.length > 1 && (
                    <button type="button" onClick={() => removeItem(index)} className="p-1.5 hover:bg-red-50 rounded text-red-500"><Trash2 className="w-4 h-4" /></button>
                  )}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-slate-100 flex justify-end">
            <div className="text-right">
              <p className="text-sm text-slate-500">Toplam</p>
              <p className="text-2xl font-bold text-slate-900">₺{totalAmount.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
          <label className="block text-sm font-medium text-slate-700 mb-2">Notlar</label>
          <textarea value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/20" rows={3} placeholder="Sipariş notları..." />
        </div>

        <div className="flex justify-end gap-3">
          <Link href="/dashboard/orders" className="px-6 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">İptal</Link>
          <button type="submit" disabled={loading} className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white font-medium hover:shadow-lg disabled:opacity-50 flex items-center gap-2">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Sipariş Oluştur
          </button>
        </div>
      </form>
    </div>
  )
}
