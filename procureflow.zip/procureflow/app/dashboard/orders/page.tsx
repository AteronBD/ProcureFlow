'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Plus, Search, Package, Eye, Edit, Truck, Clock, CheckCircle, AlertTriangle } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { formatCurrency, getDaysUntilDelivery, getDeliveryStatusText, getDeliveryStatusColor, statusConfig } from '@/lib/utils'

const filters = [
  { id: 'all', label: 'Tümü' },
  { id: 'pending', label: 'Beklemede' },
  { id: 'confirmed', label: 'Onaylı' },
  { id: 'shipped', label: 'Yolda' },
  { id: 'delivered', label: 'Teslim' },
]

export default function OrdersPage() {
  const [orders, setOrders] = useState<any[]>([])
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchOrders = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data: profile } = await supabase.from('users').select('company_id').eq('id', user.id).single()
      if (!profile) return

      const { data } = await supabase
        .from('purchase_orders')
        .select('*, suppliers(name)')
        .eq('company_id', profile.company_id)
        .order('created_at', { ascending: false })

      if (data) setOrders(data)
      setLoading(false)
    }
    fetchOrders()
  }, [])

  const filteredOrders = orders.filter(order => {
    const matchesFilter = filter === 'all' || order.status === filter
    const matchesSearch = order.po_number.toLowerCase().includes(search.toLowerCase()) ||
                         order.suppliers?.name?.toLowerCase().includes(search.toLowerCase())
    return matchesFilter && matchesSearch
  })

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'shipped': return Truck
      case 'delivered': return CheckCircle
      case 'delayed': return AlertTriangle
      default: return Clock
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div></div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Siparişler</h2>
          <p className="text-slate-500 mt-1">Tüm satın alma siparişlerinizi yönetin</p>
        </div>
        <Link href="/dashboard/orders/new" className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-sm font-medium text-white hover:shadow-lg transition-all flex items-center gap-2 w-fit">
          <Plus className="w-4 h-4" />
          Yeni Sipariş
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {filters.map((f) => (
            <button key={f.id} onClick={() => setFilter(f.id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${filter === f.id ? 'bg-cyan-500 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}>
              {f.label}
            </button>
          ))}
        </div>
        <div className="relative flex-1 max-w-xs">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input type="text" placeholder="Sipariş ara..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/20" />
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="text-left px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Sipariş No</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Tedarikçi</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Tutar</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Durum</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Teslim</th>
                <th className="text-right px-6 py-4 text-xs font-semibold text-slate-500 uppercase">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.length === 0 ? (
                <tr><td colSpan={6} className="px-6 py-12 text-center text-slate-500">Sipariş bulunamadı</td></tr>
              ) : filteredOrders.map((order) => {
                const config = statusConfig[order.status as keyof typeof statusConfig] || statusConfig.pending
                const StatusIcon = getStatusIcon(order.status)
                const daysLeft = getDaysUntilDelivery(order.expected_delivery_date)
                return (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-semibold text-slate-900">{order.po_number}</td>
                    <td className="px-6 py-4 text-slate-700">{order.suppliers?.name}</td>
                    <td className="px-6 py-4 font-medium text-slate-900">{order.total_amount ? formatCurrency(order.total_amount) : '-'}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${config.color}`}>
                        <StatusIcon className="w-3.5 h-3.5" />{config.label}
                      </span>
                    </td>
                    <td className="px-6 py-4"><span className={`font-medium ${getDeliveryStatusColor(daysLeft)}`}>{getDeliveryStatusText(daysLeft)}</span></td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-1">
                        <Link href={`/dashboard/orders/${order.id}`} className="p-2 hover:bg-slate-100 rounded-lg"><Eye className="w-4 h-4 text-slate-500" /></Link>
                        <Link href={`/dashboard/orders/${order.id}/edit`} className="p-2 hover:bg-slate-100 rounded-lg"><Edit className="w-4 h-4 text-slate-500" /></Link>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
