'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { 
  Package, Truck, AlertTriangle, CheckCircle, Clock,
  ChevronRight, Plus, TrendingUp, TrendingDown, Building2
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { 
  formatCurrency, getDaysUntilDelivery, 
  getDeliveryStatusText, getDeliveryStatusColor, statusConfig,
  getScoreColor
} from '@/lib/utils'

function StatCard({ icon: Icon, label, value, color }: {
  icon: any; label: string; value: string | number; color: string
}) {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-all">
      <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center shadow-lg`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div className="mt-4">
        <p className="text-3xl font-bold text-slate-900">{value}</p>
        <p className="text-sm text-slate-500 mt-1">{label}</p>
      </div>
    </div>
  )
}

export default function DashboardPage() {
  const [stats, setStats] = useState({ activeOrders: 0, inTransit: 0, delayed: 0, delivered: 0 })
  const [recentOrders, setRecentOrders] = useState<any[]>([])
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data: profile } = await supabase.from('users').select('company_id').eq('id', user.id).single()
      if (!profile) return

      const { data: orders } = await supabase
        .from('purchase_orders')
        .select('*, suppliers(name)')
        .eq('company_id', profile.company_id)
        .order('created_at', { ascending: false })

      if (orders) {
        const active = orders.filter(o => !['delivered', 'cancelled'].includes(o.status))
        const inTransit = orders.filter(o => o.status === 'shipped')
        const delayed = orders.filter(o => {
          if (!o.expected_delivery_date || o.status === 'delivered') return false
          const days = getDaysUntilDelivery(o.expected_delivery_date)
          return days !== null && days < 0
        })
        const delivered = orders.filter(o => o.status === 'delivered')
        setStats({ activeOrders: active.length, inTransit: inTransit.length, delayed: delayed.length, delivered: delivered.length })
        setRecentOrders(orders.slice(0, 5))
      }

      const { data: suppliersData } = await supabase
        .from('suppliers')
        .select('*, supplier_performance(*)')
        .eq('company_id', profile.company_id)
        .limit(5)
      if (suppliersData) setSuppliers(suppliersData)

      setLoading(false)
    }
    fetchData()
  }, [])

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div></div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Dashboard</h2>
          <p className="text-slate-500 mt-1">Hoş geldiniz. İşte bugünkü özet.</p>
        </div>
        <Link href="/dashboard/orders/new" className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-sm font-medium text-white hover:shadow-lg transition-all flex items-center gap-2 w-fit">
          <Plus className="w-4 h-4" />
          Yeni Sipariş
        </Link>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Package} label="Aktif Siparişler" value={stats.activeOrders} color="bg-gradient-to-br from-blue-500 to-blue-600" />
        <StatCard icon={Truck} label="Yolda" value={stats.inTransit} color="bg-gradient-to-br from-purple-500 to-purple-600" />
        <StatCard icon={AlertTriangle} label="Geciken" value={stats.delayed} color="bg-gradient-to-br from-red-500 to-red-600" />
        <StatCard icon={CheckCircle} label="Teslim Edilen" value={stats.delivered} color="bg-gradient-to-br from-emerald-500 to-emerald-600" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-100">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-semibold text-slate-900">Son Siparişler</h3>
            <Link href="/dashboard/orders" className="text-sm text-cyan-600 hover:text-cyan-700 font-medium flex items-center gap-1">
              Tümü <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="divide-y divide-slate-100">
            {recentOrders.length === 0 ? (
              <div className="px-6 py-12 text-center text-slate-500">Henüz sipariş yok</div>
            ) : recentOrders.map((order) => {
              const config = statusConfig[order.status as keyof typeof statusConfig] || statusConfig.pending
              const daysLeft = getDaysUntilDelivery(order.expected_delivery_date)
              return (
                <Link key={order.id} href={`/dashboard/orders/${order.id}`} className="px-6 py-4 hover:bg-slate-50 flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-xl ${config.color} flex items-center justify-center`}>
                    <Package className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="font-semibold text-slate-900">{order.po_number}</span>
                    <p className="text-sm text-slate-500 truncate">{order.suppliers?.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-slate-900">{order.total_amount ? formatCurrency(order.total_amount) : '-'}</p>
                    <p className={`text-sm ${getDeliveryStatusColor(daysLeft)}`}>{getDeliveryStatusText(daysLeft)}</p>
                  </div>
                </Link>
              )
            })}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-100">
          <div className="px-6 py-4 border-b border-slate-100">
            <h3 className="font-semibold text-slate-900">Tedarikçiler</h3>
          </div>
          <div className="divide-y divide-slate-100">
            {suppliers.length === 0 ? (
              <div className="px-6 py-12 text-center text-slate-500">Henüz tedarikçi yok</div>
            ) : suppliers.map((supplier) => {
              const perf = supplier.supplier_performance?.[0]
              const score = perf?.overall_score || 0
              return (
                <Link key={supplier.id} href={`/dashboard/suppliers/${supplier.id}`} className="px-6 py-4 hover:bg-slate-50 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-slate-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-900 truncate">{supplier.name}</p>
                    <p className="text-xs text-slate-500">{supplier.category || 'Genel'}</p>
                  </div>
                  <div className={`text-lg font-bold ${getScoreColor(score)}`}>{score || '-'}</div>
                </Link>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
