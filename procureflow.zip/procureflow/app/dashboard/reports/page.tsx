'use client'

import { BarChart3, Truck, FileText, Bell, ArrowUpRight, Download } from 'lucide-react'

const reports = [
  {
    title: 'Tedarikçi Performans Raporu',
    description: 'Tüm tedarikçilerin karşılaştırmalı performans analizi',
    icon: BarChart3,
    color: 'from-blue-500 to-blue-600',
  },
  {
    title: 'Teslimat Analizi',
    description: 'Zamanında teslimat oranları ve gecikme detayları',
    icon: Truck,
    color: 'from-purple-500 to-purple-600',
  },
  {
    title: 'Maliyet Raporu',
    description: 'Satın alma harcamalarının detaylı dökümü',
    icon: FileText,
    color: 'from-emerald-500 to-emerald-600',
  },
  {
    title: 'Uyarı Etkinliği',
    description: 'Gönderilen uyarıların performans analizi',
    icon: Bell,
    color: 'from-amber-500 to-amber-600',
  },
]

export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Raporlar</h2>
        <p className="text-slate-500 mt-1">Detaylı analiz ve raporlama</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {reports.map((report, i) => {
          const Icon = report.icon
          return (
            <div
              key={i}
              className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 hover:shadow-md hover:border-slate-200 transition-all cursor-pointer group"
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${report.color} flex items-center justify-center shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-900 group-hover:text-cyan-600 transition-colors">
                    {report.title}
                  </h3>
                  <p className="text-sm text-slate-500 mt-1">{report.description}</p>
                </div>
                <ArrowUpRight className="w-5 h-5 text-slate-400 group-hover:text-cyan-600 transition-colors" />
              </div>
              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-sm text-slate-500">Son güncelleme: Bugün</span>
                <button className="flex items-center gap-1 text-sm text-cyan-600 hover:text-cyan-700 font-medium">
                  <Download className="w-4 h-4" />
                  İndir
                </button>
              </div>
            </div>
          )
        })}
      </div>

      <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-8 text-white">
        <h3 className="text-xl font-semibold mb-2">Özel Rapor Oluştur</h3>
        <p className="text-slate-400 mb-6">
          İhtiyacınıza göre özelleştirilmiş raporlar oluşturun. Tarih aralığı, tedarikçi ve metrik seçerek
          detaylı analizler alın.
        </p>
        <button className="px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl font-medium transition-colors">
          Rapor Oluşturucu (Yakında)
        </button>
      </div>
    </div>
  )
}
