'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Plus, Search, Building2, TrendingUp, TrendingDown, Mail, Phone } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { getScoreColor, getScoreBgColor } from '@/lib/utils'

export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [companyId, setCompanyId] = useState('')
  const [newSupplier, setNewSupplier] = useState({ name: '', email: '', phone: '', category: '', address: '' })

  useEffect(() => {
    fetchSuppliers()
  }, [])

  const fetchSuppliers = async () => {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { data: profile } = await supabase.from('users').select('company_id').eq('id', user.id).single()
    if (!profile) return
    setCompanyId(profile.company_id)

    const { data } = await supabase
      .from('suppliers')
      .select('*, supplier_performance(*)')
      .eq('company_id', profile.company_id)
      .order('name')

    if (data) setSuppliers(data)
    setLoading(false)
  }

  const handleAddSupplier = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    
    const { error } = await supabase.from('suppliers').insert({
      company_id: companyId,
      name: newSupplier.name,
      email: newSupplier.email,
      phone: newSupplier.phone,
      category: newSupplier.category,
      address: newSupplier.address,
      status: 'active',
    })

    if (!error) {
      setShowModal(false)
      setNewSupplier({ name: '', email: '', phone: '', category: '', address: '' })
      fetchSuppliers()
    }
  }

  const filteredSuppliers = suppliers.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.category?.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div></div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Tedarikçiler</h2>
          <p className="text-slate-500 mt-1">Tedarikçilerinizi yönetin ve performanslarını takip edin</p>
        </div>
        <button onClick={() => setShowModal(true)} className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-sm font-medium text-white hover:shadow-lg transition-all flex items-center gap-2 w-fit">
          <Plus className="w-4 h-4" />
          Tedarikçi Ekle
        </button>
      </div>

      <div className="relative max-w-xs">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input type="text" placeholder="Tedarikçi ara..." value={search} onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/20" />
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSuppliers.length === 0 ? (
          <div className="col-span-full text-center py-12 text-slate-500">Tedarikçi bulunamadı</div>
        ) : filteredSuppliers.map((supplier) => {
          const perf = supplier.supplier_performance?.[0]
          const score = perf?.overall_score || 0
          const onTime = perf?.on_time_deliveries || 0
          const total = perf?.total_orders || 0
          return (
            <Link key={supplier.id} href={`/dashboard/suppliers/${supplier.id}`}
              className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 hover:shadow-md hover:border-slate-200 transition-all group">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center group-hover:bg-cyan-50 transition-colors">
                  <Building2 className="w-6 h-6 text-slate-600 group-hover:text-cyan-600" />
                </div>
                {score > 0 && (
                  <div className={`text-2xl font-bold ${getScoreColor(score)}`}>{score}</div>
                )}
              </div>
              <h3 className="font-semibold text-slate-900 group-hover:text-cyan-600 transition-colors">{supplier.name}</h3>
              <p className="text-sm text-slate-500 mt-1">{supplier.category || 'Kategori belirtilmemiş'}</p>
              
              {(supplier.email || supplier.phone) && (
                <div className="mt-3 pt-3 border-t border-slate-100 space-y-1">
                  {supplier.email && (
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Mail className="w-4 h-4" />
                      <span className="truncate">{supplier.email}</span>
                    </div>
                  )}
                  {supplier.phone && (
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Phone className="w-4 h-4" />
                      {supplier.phone}
                    </div>
                  )}
                </div>
              )}

              {total > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Zamanında: {onTime}/{total}</span>
                    <span className="text-slate-500">{Math.round((onTime/total)*100)}%</span>
                  </div>
                  <div className="mt-2 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className={`h-full ${getScoreBgColor(Math.round((onTime/total)*100))} rounded-full`} style={{width: `${(onTime/total)*100}%`}} />
                  </div>
                </div>
              )}
            </Link>
          )
        })}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-100">
              <h3 className="font-semibold text-slate-900">Yeni Tedarikçi</h3>
            </div>
            <form onSubmit={handleAddSupplier} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Tedarikçi Adı *</label>
                <input type="text" value={newSupplier.name} onChange={(e) => setNewSupplier({...newSupplier, name: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Kategori</label>
                <input type="text" value={newSupplier.category} onChange={(e) => setNewSupplier({...newSupplier, category: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl" placeholder="Örn: Elektronik, Makina" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                <input type="email" value={newSupplier.email} onChange={(e) => setNewSupplier({...newSupplier, email: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Telefon</label>
                <input type="text" value={newSupplier.phone} onChange={(e) => setNewSupplier({...newSupplier, phone: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Adres</label>
                <textarea value={newSupplier.address} onChange={(e) => setNewSupplier({...newSupplier, address: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-xl" rows={2} />
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">İptal</button>
                <button type="submit" className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white font-medium">Kaydet</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
