import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ProcureFlow - Tedarik Yönetim Sistemi',
  description: 'SaaS tabanlı tedarikçi ve satın alma yönetim platformu',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  )
}
