import Link from 'next/link'
import { 
  Zap, Package, Bell, BarChart3, Shield, Clock, 
  CheckCircle, ArrowRight, Building2, Users, Truck 
} from 'lucide-react'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center shadow-lg shadow-cyan-500/25">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-xl text-slate-900">ProcureFlow</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-slate-600 hover:text-slate-900 transition-colors">Özellikler</a>
            <a href="#pricing" className="text-slate-600 hover:text-slate-900 transition-colors">Fiyatlandırma</a>
            <a href="#contact" className="text-slate-600 hover:text-slate-900 transition-colors">İletişim</a>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/auth/login" className="text-slate-600 hover:text-slate-900 transition-colors font-medium">
              Giriş Yap
            </Link>
            <Link 
              href="/auth/register" 
              className="px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white font-medium hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
            >
              Ücretsiz Başla
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-50 rounded-full text-cyan-700 text-sm font-medium mb-6">
              <Zap className="w-4 h-4" />
              Tedarik süreçlerinizi dijitalleştirin
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 leading-tight mb-6">
              Tedarikçi Performansını
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"> Takip Edin</span>
            </h1>
            <p className="text-xl text-slate-600 mb-10">
              Teslimat sürelerini izleyin, otomatik uyarılar alın ve tedarikçi performansını 
              analiz edin. Tüm satın alma süreçleriniz tek platformda.
            </p>
            <div className="flex items-center justify-center gap-4">
              <Link 
                href="/auth/register" 
                className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white font-semibold hover:shadow-xl hover:shadow-cyan-500/25 transition-all flex items-center gap-2"
              >
                Ücretsiz Deneyin
                <ArrowRight className="w-5 h-5" />
              </Link>
              <a 
                href="#demo" 
                className="px-8 py-4 bg-slate-100 rounded-xl text-slate-700 font-semibold hover:bg-slate-200 transition-colors"
              >
                Demo İzle
              </a>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: '500+', label: 'Aktif Şirket' },
              { value: '50K+', label: 'Takip Edilen Sipariş' },
              { value: '%94', label: 'Zamanında Teslimat' },
              { value: '7/24', label: 'Destek' },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-4xl font-bold text-slate-900">{stat.value}</div>
                <div className="text-slate-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-6 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Tüm İhtiyaçlarınız Tek Platformda
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Satın alma süreçlerinizi uçtan uca yönetin
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Package,
                title: 'Sipariş Takibi',
                description: 'Tüm satın alma siparişlerinizi tek ekrandan takip edin. Durum değişikliklerini anlık görün.',
                color: 'from-blue-500 to-blue-600',
              },
              {
                icon: Bell,
                title: 'Otomatik Uyarılar',
                description: 'Teslimat tarihlerinden önce ve gecikmelerde otomatik bildirimler alın.',
                color: 'from-amber-500 to-orange-500',
              },
              {
                icon: BarChart3,
                title: 'Performans Analizi',
                description: 'Tedarikçilerinizi zamanında teslimat, kalite ve uyum kriterlerine göre değerlendirin.',
                color: 'from-emerald-500 to-emerald-600',
              },
              {
                icon: Building2,
                title: 'Tedarikçi Portalı',
                description: 'Tedarikçilerinize özel portal ile teslimat bilgilerini doğrudan güncelleyin.',
                color: 'from-purple-500 to-purple-600',
              },
              {
                icon: Clock,
                title: 'Teslimat Süresi Takibi',
                description: 'Beklenen ve gerçekleşen teslimat tarihlerini karşılaştırın, gecikmeleri analiz edin.',
                color: 'from-cyan-500 to-cyan-600',
              },
              {
                icon: Shield,
                title: 'Güvenli Altyapı',
                description: 'Verileriniz şifrelenmiş ve güvenli bulut altyapısında saklanır.',
                color: 'from-slate-600 to-slate-700',
              },
            ].map((feature, i) => {
              const Icon = feature.icon
              return (
                <div key={i} className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 hover:shadow-md hover:border-slate-200 transition-all group">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center shadow-lg mb-6`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-3 group-hover:text-cyan-600 transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-slate-600">
                    {feature.description}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Nasıl Çalışır?
            </h2>
            <p className="text-lg text-slate-600">
              3 basit adımda tedarik süreçlerinizi kontrol altına alın
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '1',
                title: 'Tedarikçilerinizi Ekleyin',
                description: 'Mevcut tedarikçi listenizi sisteme aktarın veya yeni tedarikçiler ekleyin.',
              },
              {
                step: '2',
                title: 'Siparişleri Kaydedin',
                description: 'Satın alma siparişlerinizi girin, teslim tarihlerini belirleyin.',
              },
              {
                step: '3',
                title: 'Takip Edin & Analiz Edin',
                description: 'Otomatik uyarılar alın, performans raporlarını inceleyin.',
              },
            ].map((item, i) => (
              <div key={i} className="relative">
                <div className="text-8xl font-bold text-slate-100 absolute -top-4 -left-2">
                  {item.step}
                </div>
                <div className="relative pt-12">
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">
                    {item.title}
                  </h3>
                  <p className="text-slate-600">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-6 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Basit ve Şeffaf Fiyatlandırma
            </h2>
            <p className="text-lg text-slate-600">
              İhtiyacınıza göre plan seçin, istediğiniz zaman yükseltin
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: 'Başlangıç',
                price: 'Ücretsiz',
                period: '',
                description: 'Küçük işletmeler için',
                features: [
                  '5 tedarikçi',
                  '50 sipariş/ay',
                  'Email uyarıları',
                  'Temel raporlar',
                ],
                cta: 'Ücretsiz Başla',
                popular: false,
              },
              {
                name: 'Profesyonel',
                price: '₺499',
                period: '/ay',
                description: 'Büyüyen şirketler için',
                features: [
                  'Sınırsız tedarikçi',
                  'Sınırsız sipariş',
                  'Email + SMS uyarıları',
                  'Gelişmiş raporlar',
                  'Tedarikçi portalı',
                  'API erişimi',
                ],
                cta: '14 Gün Ücretsiz Dene',
                popular: true,
              },
              {
                name: 'Kurumsal',
                price: 'Özel',
                period: '',
                description: 'Büyük organizasyonlar için',
                features: [
                  'Tüm Pro özellikleri',
                  'Özel entegrasyonlar',
                  'Dedicated destek',
                  'SLA garantisi',
                  'On-premise seçeneği',
                ],
                cta: 'İletişime Geçin',
                popular: false,
              },
            ].map((plan, i) => (
              <div 
                key={i} 
                className={`bg-white rounded-2xl p-8 ${
                  plan.popular 
                    ? 'ring-2 ring-cyan-500 shadow-xl relative' 
                    : 'border border-slate-200'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full text-white text-sm font-medium">
                    En Popüler
                  </div>
                )}
                <div className="text-center mb-8">
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">{plan.name}</h3>
                  <p className="text-slate-500 text-sm mb-4">{plan.description}</p>
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-slate-900">{plan.price}</span>
                    <span className="text-slate-500 ml-1">{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-center gap-3 text-slate-600">
                      <CheckCircle className="w-5 h-5 text-cyan-500 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <button 
                  className={`w-full py-3 rounded-xl font-semibold transition-all ${
                    plan.popular
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white hover:shadow-lg hover:shadow-cyan-500/25'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {plan.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
            Tedarik Süreçlerinizi Bugün Dönüştürün
          </h2>
          <p className="text-lg text-slate-600 mb-10">
            Binlerce şirket ProcureFlow ile tedarikçi performansını artırıyor.
            Siz de ücretsiz deneyin.
          </p>
          <Link 
            href="/auth/register"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white font-semibold hover:shadow-xl hover:shadow-cyan-500/25 transition-all"
          >
            Hemen Başlayın
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-xl">ProcureFlow</span>
            </div>
            <div className="flex items-center gap-8 text-slate-400">
              <a href="#" className="hover:text-white transition-colors">Gizlilik</a>
              <a href="#" className="hover:text-white transition-colors">Kullanım Şartları</a>
              <a href="#" className="hover:text-white transition-colors">İletişim</a>
            </div>
            <p className="text-slate-500">
              © 2024 ProcureFlow. Tüm hakları saklıdır.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
