export type Database = {
  public: {
    Tables: {
      companies: {
        Row: {
          id: string
          name: string
          subscription_plan: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          subscription_plan?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          subscription_plan?: string | null
          created_at?: string
        }
      }
      users: {
        Row: {
          id: string
          company_id: string
          email: string
          name: string | null
          role: string
          created_at: string
        }
        Insert: {
          id?: string
          company_id: string
          email: string
          name?: string | null
          role?: string
          created_at?: string
        }
        Update: {
          id?: string
          company_id?: string
          email?: string
          name?: string | null
          role?: string
          created_at?: string
        }
      }
      suppliers: {
        Row: {
          id: string
          company_id: string
          name: string
          email: string | null
          phone: string | null
          address: string | null
          category: string | null
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          company_id: string
          name: string
          email?: string | null
          phone?: string | null
          address?: string | null
          category?: string | null
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          company_id?: string
          name?: string
          email?: string | null
          phone?: string | null
          address?: string | null
          category?: string | null
          status?: string
          created_at?: string
        }
      }
      purchase_orders: {
        Row: {
          id: string
          company_id: string
          supplier_id: string
          po_number: string
          status: string
          order_date: string
          expected_delivery_date: string | null
          actual_delivery_date: string | null
          total_amount: number | null
          currency: string
          notes: string | null
          created_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          company_id: string
          supplier_id: string
          po_number: string
          status?: string
          order_date: string
          expected_delivery_date?: string | null
          actual_delivery_date?: string | null
          total_amount?: number | null
          currency?: string
          notes?: string | null
          created_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          company_id?: string
          supplier_id?: string
          po_number?: string
          status?: string
          order_date?: string
          expected_delivery_date?: string | null
          actual_delivery_date?: string | null
          total_amount?: number | null
          currency?: string
          notes?: string | null
          created_by?: string | null
          created_at?: string
        }
      }
      po_items: {
        Row: {
          id: string
          po_id: string
          product_name: string
          product_code: string | null
          quantity: number
          unit: string | null
          unit_price: number
          delivered_quantity: number
          status: string
        }
        Insert: {
          id?: string
          po_id: string
          product_name: string
          product_code?: string | null
          quantity: number
          unit?: string | null
          unit_price: number
          delivered_quantity?: number
          status?: string
        }
        Update: {
          id?: string
          po_id?: string
          product_name?: string
          product_code?: string | null
          quantity?: number
          unit?: string | null
          unit_price?: number
          delivered_quantity?: number
          status?: string
        }
      }
      alert_rules: {
        Row: {
          id: string
          company_id: string
          name: string
          trigger_type: string
          trigger_value: number
          recipient_type: string
          notification_channels: string[]
          message_template: string | null
          is_active: boolean
          created_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          company_id: string
          name: string
          trigger_type: string
          trigger_value: number
          recipient_type?: string
          notification_channels?: string[]
          message_template?: string | null
          is_active?: boolean
          created_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          company_id?: string
          name?: string
          trigger_type?: string
          trigger_value?: number
          recipient_type?: string
          notification_channels?: string[]
          message_template?: string | null
          is_active?: boolean
          created_by?: string | null
          created_at?: string
        }
      }
      alerts_sent: {
        Row: {
          id: string
          alert_rule_id: string | null
          po_id: string
          recipient_email: string
          channel: string
          sent_at: string
          status: string
        }
        Insert: {
          id?: string
          alert_rule_id?: string | null
          po_id: string
          recipient_email: string
          channel: string
          sent_at?: string
          status?: string
        }
        Update: {
          id?: string
          alert_rule_id?: string | null
          po_id?: string
          recipient_email?: string
          channel?: string
          sent_at?: string
          status?: string
        }
      }
      supplier_performance: {
        Row: {
          id: string
          supplier_id: string
          period_start: string
          period_end: string
          total_orders: number
          on_time_deliveries: number
          late_deliveries: number
          avg_delay_days: number | null
          quality_acceptance_rate: number | null
          po_compliance_rate: number | null
          overall_score: number | null
          calculated_at: string
        }
        Insert: {
          id?: string
          supplier_id: string
          period_start: string
          period_end: string
          total_orders?: number
          on_time_deliveries?: number
          late_deliveries?: number
          avg_delay_days?: number | null
          quality_acceptance_rate?: number | null
          po_compliance_rate?: number | null
          overall_score?: number | null
          calculated_at?: string
        }
        Update: {
          id?: string
          supplier_id?: string
          period_start?: string
          period_end?: string
          total_orders?: number
          on_time_deliveries?: number
          late_deliveries?: number
          avg_delay_days?: number | null
          quality_acceptance_rate?: number | null
          po_compliance_rate?: number | null
          overall_score?: number | null
          calculated_at?: string
        }
      }
    }
  }
}

export type Company = Database['public']['Tables']['companies']['Row']
export type User = Database['public']['Tables']['users']['Row']
export type Supplier = Database['public']['Tables']['suppliers']['Row']
export type PurchaseOrder = Database['public']['Tables']['purchase_orders']['Row']
export type POItem = Database['public']['Tables']['po_items']['Row']
export type AlertRule = Database['public']['Tables']['alert_rules']['Row']
export type AlertSent = Database['public']['Tables']['alerts_sent']['Row']
export type SupplierPerformance = Database['public']['Tables']['supplier_performance']['Row']

// Extended types with relations
export type PurchaseOrderWithSupplier = PurchaseOrder & {
  suppliers: Supplier
}

export type PurchaseOrderWithItems = PurchaseOrder & {
  po_items: POItem[]
  suppliers: Supplier
}

export type SupplierWithPerformance = Supplier & {
  supplier_performance: SupplierPerformance[]
}
