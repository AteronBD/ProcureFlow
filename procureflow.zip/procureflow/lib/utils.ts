import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, formatDistanceToNow, differenceInDays, parseISO } from 'date-fns'
import { tr } from 'date-fns/locale'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number, currency: string = 'TRY') {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatDate(date: string | Date) {
  const d = typeof date === 'string' ? parseISO(date) : date
  return format(d, 'd MMM yyyy', { locale: tr })
}

export function formatDateTime(date: string | Date) {
  const d = typeof date === 'string' ? parseISO(date) : date
  return format(d, 'd MMM yyyy HH:mm', { locale: tr })
}

export function formatRelativeTime(date: string | Date) {
  const d = typeof date === 'string' ? parseISO(date) : date
  return formatDistanceToNow(d, { addSuffix: true, locale: tr })
}

export function getDaysUntilDelivery(expectedDate: string | null) {
  if (!expectedDate) return null
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const expected = parseISO(expectedDate)
  expected.setHours(0, 0, 0, 0)
  return differenceInDays(expected, today)
}

export function getDeliveryStatusText(daysLeft: number | null) {
  if (daysLeft === null) return 'Tarih belirlenmemiş'
  if (daysLeft < 0) return `${Math.abs(daysLeft)} gün gecikti`
  if (daysLeft === 0) return 'Bugün'
  if (daysLeft === 1) return 'Yarın'
  return `${daysLeft} gün kaldı`
}

export function getDeliveryStatusColor(daysLeft: number | null) {
  if (daysLeft === null) return 'text-slate-500'
  if (daysLeft < 0) return 'text-red-600'
  if (daysLeft <= 3) return 'text-amber-600'
  return 'text-slate-600'
}

export const statusConfig = {
  pending: { label: 'Beklemede', color: 'bg-slate-100 text-slate-700', bgColor: 'bg-slate-500' },
  confirmed: { label: 'Onaylandı', color: 'bg-blue-100 text-blue-700', bgColor: 'bg-blue-500' },
  shipped: { label: 'Yolda', color: 'bg-purple-100 text-purple-700', bgColor: 'bg-purple-500' },
  delivered: { label: 'Teslim Edildi', color: 'bg-emerald-100 text-emerald-700', bgColor: 'bg-emerald-500' },
  delayed: { label: 'Gecikti', color: 'bg-red-100 text-red-700', bgColor: 'bg-red-500' },
  cancelled: { label: 'İptal', color: 'bg-gray-100 text-gray-500', bgColor: 'bg-gray-500' },
} as const

export type OrderStatus = keyof typeof statusConfig

export function getScoreColor(score: number) {
  if (score >= 90) return 'text-emerald-600'
  if (score >= 75) return 'text-amber-600'
  return 'text-red-600'
}

export function getScoreBgColor(score: number) {
  if (score >= 90) return 'bg-emerald-500'
  if (score >= 75) return 'bg-amber-500'
  return 'bg-red-500'
}

export function generatePONumber() {
  const year = new Date().getFullYear()
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
  return `PO-${year}-${random}`
}
